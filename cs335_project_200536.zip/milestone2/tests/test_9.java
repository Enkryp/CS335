class functionandIfElse
{  
    public static int function1(){
        int j=0;
        int k=j;
        return k+j;
    }
    
    public static void main()   
    {  
        
        function1();
        int arr[] = { 4, 3, 2, 1 };
        
		// Outer loop
		int a=arr[0];
		int b=arr[1];
		int d=a+b;
		{
            int e=d;
		}
		{
            int e=d;
		}
		{int f=d;}
		int e=d;
        int n=a+5;
        if(n<2){
            n=5;
        }
        else {
            n=10;
        }
    }  
}  