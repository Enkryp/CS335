// Java Program to sort an elements
// by bringing Arrays into play

// Main class
class Variableandarray {

	// Main driver method
	public static void main(String args[])
	{

		// Custom input array
		int arr[] = { 4, 3, 2, 1 };

		// Outer loop
		int a=arr[0];
		int b=arr[1];
		int d=a+b;
		{
			int e=d;
		}
		{
			int e=d;
		}
		{int f=d;}
		int e=d;
	}
}
