 class functionandWhileandIfelse
{  
    int l=0;
    int k=1;
    // public static int function2(int l){
    //     int j=0;
    //     int k=j;
    //     return k+j;
    // }
    
    public static void main()   
    {  
        // int l=0;
        // function2(l);
        // int arr[] = { 4, 3, 2, 1 };
        
		// Outer loop
		// int a=0;
		// int b=0;
		// int d=a+b;
		// {
        //     int e=d;
		// }
		// {
        //     int e=d;
		// }
		// {int f=d;}
		// int e=d;
        // int n=a+5;
        // if(n<2){
        //     n=5;
        //     while(a>b){
        //         b++;
        //     }
        // }
        // else {
        //     n=10;
        //     while(a>b){
        //         b++;
        //     }
        // }
        // if(n<2){
        //     n=5;
        //     while(a>b){
        //         b++;
        //     }
        // }
        // else {
        //     n=10;
        //     while(a>b){
        //         b++;
        //     }
        // }
        // function2(a);

    }  
}  