class functionandfields
{  
    int l=0;
    int alpha =1;
    public static int function1(){
        int j=0;
        int k=j;
        return k+j;
    }
    public static int function2(){
      int i=0;
      return i;
    }
    public static int function3(int k){
      return k;
    }

    public static void main()   
    {  
        int a=0;
        int n=a+5;
        
        function1();
        function2();
        function3(n);
    }  
}  