class scopes
{  
    public static void main(String args[])
    {  
	{int x = 20;
	int y = 18;
	if (x > y){ 
  		int z=x+y;
    }  
	int z=x+y;}
	{int x = 20;
	int y = 18;
	if (x > y){ 
  		int z=x+y;
    }  
	int z=x+y;}
	{int x = 20;
	int y = 18;
	if (x > y){ 
  		int z=x+y;
    }  
	int z=x+y;}
	{int x = 20;
	int y = 18;
	if (x > y){ 
  		int z=x+y;
    }  
	int z=x+y;}
	int x = 20;
	int y = 18;
	if (x > y){ 
  		int z=x+y;
    }  
	int z=x+y;
}}

