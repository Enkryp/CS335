class VariableDec {
  public static void main(String args[]) {
    int a=0;
    int b=0;
    int c=a+b;
    float d=1;
    float e=c+d;

  }
}
